﻿using System;

namespace WindowsFormsApp1
{
    class DataMapper
    {
        public string StringValue1
        { get; set; }
        public string StringValue2
        { get; set; }
        public string StringValue3
        { get; set; }
        public string StringValue4
        { get; set; }
        public string StringValue5
        { get; set; }

        public long LongValue1
        { get; set; }
        public long LongValue2
        { get; set; }
        public long LongValue3
        { get; set; }
        public long LongValue4
        { get; set; }
        public long LongValue5
        { get; set; }

        public int IntValue1
        { get; set; }
        public int IntValue2
        { get; set; }
        public int IntValue3
        { get; set; }
        public int IntValue4
        { get; set; }
        public int IntValue5
        { get; set; }

        public double DoubleValue1
        { get; set; }
        public double DoubleValue2
        { get; set; }
        public double DoubleValue3
        { get; set; }
        public double DoubleValue4
        { get; set; }
        public double DoubleValue5
        { get; set; }

        public DateTime DateTimeValue1
        { get; set; }
        public DateTime DateTimeValue2
        { get; set; }
        public DateTime DateTimeValue3
        { get; set; }
        public DateTime DateTimeValue4
        { get; set; }
        public DateTime DateTimeValue5
        { get; set; }
    }
}
